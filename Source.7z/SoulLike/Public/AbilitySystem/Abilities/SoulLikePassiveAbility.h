// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "AbilitySystem/Abilities/SoulLikeGameplayAbility.h"
#include "SoulLikePassiveAbility.generated.h"

class UAbilityTask_PlayMontageAndWait;
/**
 * 
 */
UCLASS()
class SOULLIKE_API USoulLikePassiveAbility : public USoulLikeGameplayAbility
{
	GENERATED_BODY()
	

	
};
